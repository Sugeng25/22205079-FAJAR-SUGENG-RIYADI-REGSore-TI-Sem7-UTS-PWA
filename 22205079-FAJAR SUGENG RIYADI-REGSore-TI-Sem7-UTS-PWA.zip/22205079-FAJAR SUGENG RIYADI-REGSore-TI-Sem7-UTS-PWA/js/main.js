if ("serviceWorker" in navigator) {
  window.addEventListener("load", function () {
    navigator.serviceWorker
      .register("./sw.js")
      .then((res) => console.log("service worker registered"))
      .catch((err) => console.log("service worker not registered", err));
  });
}
Notification.requestPermission(function (status) {
  console.log("Notification permission status:", status);
});

Notification.requestPermission().then(function (permission) {
  if (permission == "granted") {
    alert("Terima kasih sudah accept");
  } else if (permission == "denied") {
    alert("Pemberitahuan Web Telah di Blok");
  }
});