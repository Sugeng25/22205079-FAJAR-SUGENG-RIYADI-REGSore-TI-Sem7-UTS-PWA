var cacheName = 'hello-pwa';
var filesToCache = [
  '/',
  '/index.html',
  '/css/bootstrap.min.css',
  '/css/font-awesome.min.css',
  '/css/templatemo-style.css',
  '/js/main.js',
  '/js/bootstrap.min.js',
  '/js/custom.js',
  '/js/imagesloaded.min.js',
  '/js/isotope.js',
  '/js/jquery.js',
  '/js/jquery.nav.js',
  '/js/smoothscroll.js',
];

/* Start the service worker and cache all of the app's content */
self.addEventListener('install', function (e) {
  e.waitUntil(
    caches.open(cacheName).then(function (cache) {
      return cache.addAll(filesToCache);
    })
  );
  self.skipWaiting();
});

/* Serve cached content when offline */
self.addEventListener('fetch', function (e) {
  e.respondWith(
    caches.match(e.request).then(function (response) {
      return response || fetch(e.request);
    })
  );
});
